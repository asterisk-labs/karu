Karu brand kit

The mark is a khipu, the knotted cords the Inca used to keep records that
messengers carried far. The top cord is the remote object, each hanging cord a
byte-range read and its knot the offset the bytes land at. Karu is the Quechua
word for far.

svg/  vector marks, logos, icons and avatars
png/  favicons, avatars at 400 px and logos at 1200 px

Colours  violet #492ae8, pink #f05b7f, yellow #f7cc09, mint #c4ffc2,
         ink #000000, paper #ffffff, night #111111
Wordmark League Spartan SemiBold, set as outlines

Keep the cords square ended and the colours in their order. Do not round the
corners, stretch, rotate or recolour the mark.
